//
//  Shoe Size.swift
//  Univert
//
//  Created by Adrian Neshad on 2025-05-04.
//

import SwiftUI

struct ShoeSizeRow {
    let eu: Double
    let uk: Double
    let usM: Double
    let usW: Double
    let cm: Double
}

struct Skostorlek: View {
    @AppStorage("useSwedishDecimal") private var useSwedishDecimal = true
    @State private var selectedFromUnit: String? = "EU"
    @State private var selectedToUnit: String? = "EU"
    @State private var inputValue = ""
    @State private var outputValue = ""
    @AppStorage("appLanguage") private var appLanguage = "sv" // default: svenska

    @AppStorage("savedUnits") private var savedUnitsData: Data?
    @State private var isFavorite = false

    let unitName = "Skostorlek"
    
    let units = ["EU", "UK", "US M", "US W", "cm", "in"]
    
    let fullNames: [String: String] = [
        "EU": "European Union",
        "UK": "United Kingdom",
        "US M": "US Men's",
        "US W": "US Women's",
        "cm": "Centimeter",
        "in": "Inch"
    ]
    
    let shoeSizeTable: [ShoeSizeRow] = [
        ShoeSizeRow(eu: 35, uk: 2.5, usM: 3, usW: 4, cm: 22),
        ShoeSizeRow(eu: 36, uk: 3.5, usM: 4, usW: 5, cm: 22.5),
        ShoeSizeRow(eu: 37, uk: 4, usM: 4.5, usW: 5.5, cm: 23),
        ShoeSizeRow(eu: 37.5, uk: 4.5, usM: 5, usW: 6, cm: 23.5),
        ShoeSizeRow(eu: 38, uk: 5, usM: 5.5, usW: 6.5, cm: 24),
        ShoeSizeRow(eu: 38.5, uk: 5.5, usM: 6, usW: 7, cm: 24.5),
        ShoeSizeRow(eu: 39, uk: 6, usM: 6.5, usW: 7.5, cm: 25),
        ShoeSizeRow(eu: 40, uk: 6.5, usM: 7, usW: 8, cm: 25.5),
        ShoeSizeRow(eu: 40.5, uk: 7, usM: 7.5, usW: 8.5, cm: 26),
        ShoeSizeRow(eu: 41, uk: 7, usM: 8, usW: 9, cm: 26),
        ShoeSizeRow(eu: 42, uk: 8, usM: 9, usW: 10, cm: 27),
        ShoeSizeRow(eu: 42.5, uk: 8.5, usM: 9.5, usW: 10.5, cm: 27.5),
        ShoeSizeRow(eu: 43, uk: 9, usM: 10, usW: 11, cm: 28),
        ShoeSizeRow(eu: 44, uk: 9.5, usM: 10.5, usW: 11.5, cm: 28.5),
        ShoeSizeRow(eu: 44.5, uk: 10, usM: 11, usW: 12, cm: 29),
        ShoeSizeRow(eu: 45, uk: 10.5, usM: 11.5, usW: 12.5, cm: 29.5),
        ShoeSizeRow(eu: 46, uk: 11, usM: 12, usW: 13, cm: 30),
        ShoeSizeRow(eu: 46.5, uk: 11.5, usM: 12.5, usW: 13.5, cm: 30.5),
        ShoeSizeRow(eu: 47, uk: 12, usM: 13, usW: 14, cm: 31),
        ShoeSizeRow(eu: 48, uk: 13, usM: 14, usW: 15, cm: 32),
        ShoeSizeRow(eu: 49, uk: 14, usM: 15, usW: 16, cm: 33),
        ShoeSizeRow(eu: 50, uk: 15, usM: 16, usW: 17, cm: 34)
    ]

    
    var body: some View {
        VStack {
            HStack {
                Text(appLanguage == "sv" ? "Från" : "From")
                    .font(.title)
                    .bold()
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .frame(height: 50)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)
                    .multilineTextAlignment(.center)
                
                Text("➤")
                    .font(.title)
                    .bold()
                    .frame(width: 100)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)

                Text(appLanguage == "sv" ? "Till" : "To")
                    .font(.title)
                    .bold()
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .frame(height: 50)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)
                    .multilineTextAlignment(.center)
            }
            
            HStack {
                Text("►")
                    .font(.title)
                    .frame(width: 50)
                PomodoroPicker(
                    selection: $selectedFromUnit,
                    options: units
                ) { unit in
                    Text(unit)
                        .font(.title)
                        .bold()
                        .frame(width: 100)
                        .padding(.leading, -90)
                }
                PomodoroPicker(
                    selection: $selectedToUnit,
                    options: units
                ) { unit in
                    Text(unit)
                        .font(.title)
                        .bold()
                        .frame(width: 100)
                        .padding(.trailing, -90)
                }
                Text("◄")
                    .font(.title)
                    .frame(width: 50)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 180)
            
            HStack {
                Text("(\(selectedFromUnit ?? "")) \(fullNames[selectedFromUnit ?? ""] ?? "")")
                    .font(.system(size: 15))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 10)
                
                Text("(\(selectedToUnit ?? "")) \(fullNames[selectedToUnit ?? ""] ?? "")")
                    .font(.system(size: 15))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 0)
            }
            
            HStack(spacing: 10) {
                TextField(appLanguage == "sv" ? "Värde" : "Value", text: $inputValue)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)
                    .multilineTextAlignment(.leading)
                    .onChange(of: inputValue) { newValue in
                        if !useSwedishDecimal {
                            let replaced = newValue.replacingOccurrences(of: ",", with: ".")
                            if replaced != newValue {
                                inputValue = replaced  
                            }
                        }
                        convertUsingTable()
                    }
                    .onChange(of: selectedFromUnit) { _ in
                        convertUsingTable()
                    }
                    .onChange(of: selectedToUnit) { _ in
                        convertUsingTable()
                    }


                Text(outputValue)
                    .padding(10)
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)
                    .multilineTextAlignment(.leading)
            }
            .padding([.leading, .trailing], 10)
        }
        .padding(.top, 20)
        Spacer()
        .navigationTitle(appLanguage == "sv" ? "Skostorlek" : "Shoe Size")
        .padding()
        .onAppear {
            if let data = savedUnitsData,
               let savedUnits = try? JSONDecoder().decode([Units].self, from: data),
               let match = savedUnits.first(where: { $0.name == unitName }) {
                isFavorite = match.isFavorite
            }
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    toggleFavorite()
                }) {
                    Image(systemName: isFavorite ? "star.fill" : "star")
                }
            }
        }
    }
    func toggleFavorite() {
        var currentUnits = Units.preview()
        
        // Ladda in sparade favoritstatusar
        if let data = savedUnitsData,
           let savedUnits = try? JSONDecoder().decode([Units].self, from: data) {
            for i in 0..<currentUnits.count {
                if let saved = savedUnits.first(where: { $0.name == currentUnits[i].name }) {
                    currentUnits[i].isFavorite = saved.isFavorite
                }
            }
        }
        
        // Toggla favoritstatus för "Andelar"
        if let index = currentUnits.firstIndex(where: { $0.name == unitName }) {
            currentUnits[index].isFavorite.toggle()
            isFavorite = currentUnits[index].isFavorite
            
            if let data = try? JSONEncoder().encode(currentUnits) {
                savedUnitsData = data
            }
        }
    }
    
    func convertUsingTable() {
        guard let fromUnit = selectedFromUnit,
              let toUnit = selectedToUnit,
              let inputDouble = Double(inputValue.replacingOccurrences(of: ",", with: ".")) else {
            outputValue = ""
            return
        }
        let nearestRow = shoeSizeTable.min(by: { abs(value(for: fromUnit, in: $0) - inputDouble) < abs(value(for: fromUnit, in: $1) - inputDouble) })
        
        guard let row = nearestRow else {
            outputValue = "Ingen match"
            return
        }
        
        let output = value(for: toUnit, in: row)
        
        // Använd FormatterHelper
        outputValue = FormatterHelper.shared.formatResult(output, useSwedishDecimal: useSwedishDecimal, maximumFractionDigits: 1)
    }
    
    func value(for unit: String, in row: ShoeSizeRow) -> Double {
        switch unit {
        case "EU": return row.eu
        case "UK": return row.uk
        case "US M": return row.usM
        case "US W": return row.usW
        case "cm": return row.cm
        case "in": return row.cm / 2.54  // beräkna inch från cm
        default: return 0
        }
    }
}
